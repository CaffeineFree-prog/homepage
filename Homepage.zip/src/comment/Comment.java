package comment;

public class Comment {
	private int comment_num;
	private int m_number;
	private String comment_name;
	private String comment_content;
	private String comment_regdate;
	public Comment(int comment_num, int m_number, 
			String comment_name, String comment_content, String comment_regdate) {
		this.comment_num = comment_num;
		this.m_number = m_number;
		this.comment_name = comment_name;
		this.comment_content = comment_content;
		this.comment_regdate = comment_regdate;
	}
	public Comment() {
	}
	public int getComment_num() {
		return comment_num;
	}
	public void setComment_num(int comment_num) {
		this.comment_num = comment_num;
	}
	public int getM_number() {
		return m_number;
	}
	public void setM_number(int m_number) {
		this.m_number = m_number;
	}
	public String getComment_name() {
		return comment_name;
	}
	public void setComment_name(String comment_name) {
		this.comment_name = comment_name;
	}
	public String getComment_content() {
		return comment_content;
	}
	public void setComment_content(String comment_content) {
		this.comment_content = comment_content;
	}
	public String getComment_regdate() {
		return comment_regdate;
	}
	public void setComment_regdate(String comment_regdate) {
		this.comment_regdate = comment_regdate;
	}
	@Override
	public String toString() {
		return "Comment [comment_num=" + comment_num + ", m_number=" + m_number + ", comment_name=" + comment_name
				+ ", comment_content=" + comment_content + ", comment_regdate=" + comment_regdate + "]";
	}
	
	

}
