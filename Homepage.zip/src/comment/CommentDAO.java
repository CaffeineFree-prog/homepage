package comment;

import java.sql.*;
import java.util.*;

import homepage.db.*;
import homepage.vo.*;

public class CommentDAO {
	
	Connection conn = null;
	Statement stmt 	= null;
	ResultSet rs 	= null;

	public int getNext() {
		String SQL = "SELECT comment_num FROM board_comment ORDER BY comment_num DESC";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				return rs.getInt(1) + 1;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return 1; //첫번째 댓글인 경우
	}
	
	//댓글 쓰기
	public int write(int m_number, String comment_name, String comment_content) {
		
		try {
		HomepageDB db = new HomepageDB();
		conn		  = db.getConnection();
		stmt		  = conn.createStatement();
		
		String sql = "insert into board_comment (comment_num, m_number, comment_name, comment_content)";
		sql 	+= " values ( ( SELECT NVL ( MAX(comment_num),0)+1 FROM board_comment ),";
		sql     += " "+m_number+",";
		sql     += " '"+comment_name+"',";
		sql     += " '"+comment_content+"')";
		stmt.executeUpdate(sql);
		
		return getNext();
			
		}catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!= null) rs.close();
				if(stmt!= null) stmt.close();
				if(conn!= null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return -1; //데이터베이스 오류
	}
	
	//댓글보기
	public ArrayList<Comment> getCommentList(int m_number){
		ArrayList<Comment> list = new ArrayList<Comment>();
		
		try {
			HomepageDB db = new HomepageDB();
			conn		  = db.getConnection();
			stmt		  = conn.createStatement();
			
			String sql = "select * from board_comment";
			sql		+= " where m_number="+m_number;
			//sql		+= " and comment_num="+comment_num;
			sql		+= " order by comment_num";
			rs		 	  = stmt.executeQuery(sql);
			
			while(rs.next()) {
				Comment co = new Comment();
				co.setComment_num(rs.getInt("comment_num"));
				co.setM_number(rs.getInt("m_number"));
				co.setComment_name(rs.getString("comment_name"));
				co.setComment_content(rs.getString("comment_content"));
				co.setComment_regdate(rs.getString("comment_regdate"));

				list.add(co);
				System.out.println(co);
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!= null) rs.close();
				if(stmt!= null) stmt.close();
				if(conn!= null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}	
		}

		return list;
		
	}
	
	
}

