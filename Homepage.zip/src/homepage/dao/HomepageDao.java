package homepage.dao;

import homepage.db.*;
import homepage.vo.HomepageVo;
import java.sql.*;
import java.util.*;

public class HomepageDao {
	
	Connection conn = null;
	Statement stmt 	= null;
	ResultSet rs 	= null;
	
	//게시물 목록 보기(불러오기)
	public List<HomepageVo> getBoardList(){
		List<HomepageVo> list = new ArrayList<HomepageVo>();
		
		try {
			HomepageDB db = new HomepageDB();
			conn		  = db.getConnection();
			stmt		  = conn.createStatement();
			String sql    = "select m_number, username, ";
			sql		+= " m_subject, m_content, ";
			sql		+= " to_char(m_regdate, 'YYYY-MM-DD HH24:MI:SS') m_regdate,";
			sql		+= " m_readcount" ;
			sql		+= " from jsp_mboard";
			sql		+= " order by m_number";
			rs		 	  = stmt.executeQuery(sql);
			
			while(rs.next()) {
				HomepageVo vo = new HomepageVo();
				vo.setM_number(rs.getInt("m_number"));
				vo.setUsername(rs.getString("username"));
				vo.setM_subject(rs.getString("m_subject"));
				vo.setM_content(rs.getString("m_content"));
				vo.setM_regdate(rs.getString("m_regdate"));
				vo.setM_readcount(rs.getInt("m_readcount"));
				
				list.add(vo);
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!= null) rs.close();
				if(stmt!= null) stmt.close();
				if(conn!= null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		return list;
	}
	
	//게시물 보기
	public HomepageVo getHomepage(int idx) {
		HomepageVo homeVo = null;
		
		try {
			HomepageDB db = new HomepageDB();
			conn		  = db.getConnection();
			stmt		  = conn.createStatement();
			
			String sql    = "select m_number, username, ";
			sql		+= " m_subject, m_content, ";
			sql		+= " to_char(m_regdate, 'YYYY-MM-DD HH24:MI:SS') m_regdate,";
			sql		+= " m_readcount" ;
			sql		+= " from jsp_mboard";
			sql		+= " where m_number=" + idx;
			sql		+= " order by m_number";
			
			rs = stmt.executeQuery(sql);
			
			if(rs.next()) {
				int m_number	 = rs.getInt("m_number");
				String username  = rs.getString("username");
				String m_subject = rs.getString("m_subject");
				String m_content = rs.getString("m_content");
				String m_regdate = rs.getString("m_regdate");
				int m_readcount  = rs.getInt("m_readcount");
				
				homeVo = new HomepageVo(m_number, username, m_subject, m_content, m_regdate, m_readcount);
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return homeVo;
	}

	//게시글 쓴거 저장
	public void insertBoard(String name, String sub, String cont) {
		
		try {
			HomepageDB db = new HomepageDB();
			conn		  = db.getConnection();
			stmt		  = conn.createStatement();
			
			String sql = "insert into jsp_mboard (m_number, username, ";
			sql		+= " m_subject, m_content, m_readcount)" ;
			sql		+= " values (( SELECT NVL ( MAX(m_number),0)+1 FROM jsp_mboard ), ";
			sql		+= "'"+name+"',";
			sql		+= "'"+sub+"',";
			sql		+= "'"+cont+"',";
			sql		+= " 1 )";
			
			stmt.executeUpdate(sql);
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!= null) rs.close();
				if(stmt!= null) stmt.close();
				if(conn!= null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
	}
	
	//조회수 증가
	public HomepageVo updateReadcount(int idx) {
		HomepageVo homeCnt = null;
		
		try {
			HomepageDB db = new HomepageDB();
			conn		  = db.getConnection();
			stmt		  = conn.createStatement();
			String sql    = "update jsp_mboard";
			sql			+= " set m_readcount = m_readcount+1";
			sql			+= " where m_number="+idx;
			
			stmt.executeUpdate(sql);
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!= null) rs.close();
				if(stmt!= null) stmt.close();
				if(conn!= null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		return homeCnt;
		
	}
	
	
	
	
}
