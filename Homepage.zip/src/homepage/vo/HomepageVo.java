package homepage.vo;

public class HomepageVo {
	private int m_number;
	private String username;
	private String m_subject;
	private String m_content;
	private String m_regdate;
	private int m_readcount;
	
	public HomepageVo() {
	}

	public HomepageVo(int m_number, String username, String m_subject, String m_content, String m_regdate,
			int m_readcount) {
		super();
		this.m_number = m_number;
		this.username = username;
		this.m_subject = m_subject;
		this.m_content = m_content;
		this.m_regdate = m_regdate;
		this.m_readcount = m_readcount;
	}

	public int getM_number() {
		return m_number;
	}

	public void setM_number(int m_number) {
		this.m_number = m_number;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getM_subject() {
		return m_subject;
	}

	public void setM_subject(String m_subject) {
		this.m_subject = m_subject;
	}

	public String getM_content() {
		return m_content;
	}

	public void setM_content(String m_content) {
		this.m_content = m_content;
	}

	public String getM_regdate() {
		return m_regdate;
	}

	public void setM_regdate(String m_regdate) {
		this.m_regdate = m_regdate;
	}

	public int getM_readcount() {
		return m_readcount;
	}

	public void setM_readcount(int m_readcount) {
		this.m_readcount = m_readcount;
	}

	@Override
	public String toString() {
		return "HomepageVo [m_number=" + m_number + ", username=" + username + ", m_subject=" + m_subject
				+ ", m_content=" + m_content + ", m_regdate=" + m_regdate + ", m_readcount=" + m_readcount + "]";
	}
	
	
}

